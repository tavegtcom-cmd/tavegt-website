const PHONE="917302271502";
const ADMIN_PIN="7302";
const defaultServices=[
 {id:"s1",name:"Water Tank & Pipeline Cleaning",desc:"पानी की टंकी और पाइपलाइन की सफाई",price:"जाँच के बाद"},
 {id:"s2",name:"Decoration & Events",desc:"जन्मदिन, शादी और कार्यक्रम सजावट",price:"काम के अनुसार"},
 {id:"s3",name:"Catering & Food",desc:"कार्यक्रमों के लिए खाना और कैटरिंग",price:"मेन्यू के अनुसार"},
 {id:"s4",name:"Manpower Service",desc:"जरूरत के अनुसार कामगार उपलब्ध",price:"काम के अनुसार"},
 {id:"s5",name:"Invitation Service",desc:"निमंत्रण कार्ड और डिजिटल निमंत्रण",price:"डिजाइन के अनुसार"}
];
const defaultProducts=[
 {id:"p1",name:"Food Products",price:"कीमत जोड़ें",category:"Food"},
 {id:"p2",name:"Daily Use Products",price:"कीमत जोड़ें",category:"Daily Needs"},
 {id:"p3",name:"Home Essentials",price:"कीमत जोड़ें",category:"Home"}
];
let products=JSON.parse(localStorage.getItem("tavegt_products")||"null")||defaultProducts;
let cart=[];
const save=()=>localStorage.setItem("tavegt_products",JSON.stringify(products));
function renderServices(){document.getElementById("serviceList").innerHTML=defaultServices.map(s=>`<article class="card"><h3>${s.name}</h3><p>${s.desc}</p><div class="price">${s.price}</div><button class="primary" onclick="addToCart('${s.name}')">बुक करें</button></article>`).join("")}
function renderProducts(){const q=(document.getElementById("searchProduct")?.value||"").toLowerCase();const cat=document.getElementById("categoryFilter")?.value||"all";const list=products.filter(p=>(p.name.toLowerCase().includes(q))&&(cat==="all"||p.category===cat));document.getElementById("productList").innerHTML=list.length?list.map(p=>`<article class="card"><div style="font-size:30px">🛍️</div><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.category)}</p><div class="price">${escapeHtml(String(p.price))==="कीमत जोड़ें"?"कीमत जोड़ें":"₹"+escapeHtml(String(p.price))}</div><button class="primary" onclick="addToCart('${String(p.name).replace(/'/g,"\\'")}')">कार्ट में जोड़ें</button></article>`).join(""):'<div class="empty">कोई प्रोडक्ट नहीं मिला।</div>';renderAdminProducts()}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
window.addToCart=function(name){cart.push(name);document.getElementById("cartItems").textContent="आपने चुना: "+cart.join(", ")};
document.getElementById("checkoutBtn").addEventListener("click",()=>{if(!cart.length){alert("पहले कोई सेवा या प्रोडक्ट चुनें।");return}const name=document.getElementById("customerName").value.trim();const address=document.getElementById("customerAddress").value.trim();const mode=document.getElementById("paymentMode").value;if(!name||!address){alert("कृपया नाम और पता भरें।");return}const msg=`नमस्ते TAVEGT, मुझे ऑर्डर/बुकिंग करनी है.%0Aनाम: ${encodeURIComponent(name)}%0Aपता: ${encodeURIComponent(address)}%0Aचुनी गई चीजें: ${encodeURIComponent(cart.join(", "))}%0Aभुगतान: ${encodeURIComponent(mode)}`;window.open(`https://wa.me/${PHONE}?text=${msg}`,"_blank")});
document.getElementById("searchProduct").addEventListener("input",renderProducts);document.getElementById("categoryFilter").addEventListener("change",renderProducts);
document.getElementById("unlockAdmin").addEventListener("click",()=>{if(document.getElementById("adminPin").value===ADMIN_PIN){document.getElementById("adminArea").hidden=false;renderAdminProducts()}else alert("गलत PIN")});
document.getElementById("addProduct").addEventListener("click",()=>{const name=document.getElementById("newProductName").value.trim();const price=document.getElementById("newProductPrice").value;const category=document.getElementById("newProductCategory").value;if(!name||price===""){alert("नाम और कीमत भरें");return}products.push({id:"p"+Date.now(),name,price,category});save();document.getElementById("newProductName").value="";document.getElementById("newProductPrice").value="";renderProducts()});
function renderAdminProducts(){const el=document.getElementById("adminProductList");if(!el)return;el.innerHTML=products.map((p,i)=>`<p>${escapeHtml(p.name)} — ₹${escapeHtml(String(p.price))} <button class="secondary" onclick="deleteProduct(${i})">हटाएँ</button></p>`).join("")||"कोई प्रोडक्ट नहीं"}
window.deleteProduct=function(i){products.splice(i,1);save();renderProducts()};
document.getElementById("resetData").addEventListener("click",()=>{if(confirm("डेमो प्रोडक्ट वापस लाएँ?")){products=defaultProducts.slice();save();renderProducts()}});
renderServices();renderProducts();
let deferredPrompt;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;const b=document.getElementById("installBtn");b.hidden=false;b.onclick=async()=>{deferredPrompt.prompt();deferredPrompt=null;b.hidden=true}});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));