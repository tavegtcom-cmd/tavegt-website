TAVEGT APP FILES - ZERO COST STARTER

IMPORTANT:
1. Ye aapki existing website ka backup/replace nahi karta. Pehle GitHub repo ka backup bana lein.
2. ZIP extract karne ke baad index.html, style.css, app.js, manifest.json, sw.js aur assets folder ko apne GitHub repo ke root me upload karein.
3. Agar repo me pehle se index.html hai, to seedha overwrite karne se pehle purana code kisi alag text file me save kar lein. Existing website ke sections ko is starter me merge karna pad sakta hai.
4. WhatsApp number code me 917302271502 set hai.
5. Demo Admin PIN: 7302. Live publish karne se pehle ise badlein.
6. Product add/delete filhaal sirf usi browser/device me save hota hai. Sabhi customers ko live product/order management dikhane ke liye online database/backend chahiye; is starter me fake multi-device admin ka daawa nahi hai.
7. Online payment abhi manual coordination option hai; payment gateway/UPI integration nahi joda gaya.
8. PWA install ke liye website HTTPS par publish honi chahiye. Install button compatible browser me dikhega.

Folder structure:
index.html
style.css
app.js
manifest.json
sw.js
assets/
